import 'package:flutter/material.dart';

class Profile extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
        children: [
    Padding(
    padding: const EdgeInsets.all(12.0),
    child: Center(
    child: SizedBox(
    child: Padding(
    padding: const EdgeInsets.all(8.0),
    child: Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: <Widget>[

    CircleAvatar(
    radius: 80.0,
    backgroundImage: NetworkImage('https://scontent.fcgy2-2.fna.fbcdn.net/v/t39.30808-6/518069887_1736541004414221_3602768239993428753_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=6ee11a&_nc_eui2=AeEH8l7h6NMyHmTauyPJtFKMVWYnGOTzy3VVZicY5PPLdbcj_J5muJlqXReY8UEwNmiiSoY9dNLfXCnVg8CDRRjT&_nc_ohc=YtLhN32UeE4Q7kNvwE8R2Yw&_nc_oc=AdnOPURnwkxfsbtaqhiOE-NMBMMzXdrITOQkDRqS6GJJLcM_1uuspf8PBC0xbjlEZKo&_nc_zt=23&_nc_ht=scontent.fcgy2-2.fna&_nc_gid=G7gOB-zlGAlmUeAxCg_3XQ&oh=00_AfUwFXAaTSs1Fq4Yo-ZQ7TXV2NqyaLZqjkQ0464Alze93g&oe=68A067C9', scale: 80),
    ),
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text('RYAN ANGELO ESCAÑO',
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold
          ),
        ),
      ),

      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text('Bachelor of Science in Information Technology 3rd Year 6th Year Edition',
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold
          ),
        ),
      ),

    ]
    )
    )
    )
    )
    )
        ]
    );
  }
}