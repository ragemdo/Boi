import 'package:flutter/material.dart';
import 'LoginScreen.dart';
class SignupScreen extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SignupScreenHome(),
    );
  }
}

class SignupScreenHome extends StatefulWidget{
  @override
  State<SignupScreenHome> createState() => _SignupScreenHomeState();
}

class _SignupScreenHomeState extends State<SignupScreenHome> {
  var hidePassword = true;
  var hidePassword1 = true;
  var idNumberController = TextEditingController();
  var fullNameController = TextEditingController();
  var usernameController = TextEditingController();
  var passwordController = TextEditingController();
  var confirmPasswordController = TextEditingController();
  void maskedUnmaskedPassword(){
    if(hidePassword == true) {
      setState(() {
        hidePassword = false;
      });
    } else {
      setState(() {
        hidePassword = true;
      });
    }
  }

  void maskedUnmaskedPassword1(){
    if(hidePassword1 == true) {
      setState(() {
        hidePassword1 = false;
      });
    } else {
      setState(() {
        hidePassword1 = true;
      });
    }
  }

  void validateInput() {
    var idNum = idNumberController.text;
    var username = usernameController.text;
    var password = passwordController.text;
    var fullName = fullNameController.text;
    var confirmPass = confirmPasswordController.text;

    if(idNum.isEmpty) {
      print("ID is empty!");
    } else if(fullName.isEmpty) {
      print("Full name is empty!");
    } else if(username.isEmpty) {
      print("Username is empty!");
    } else if(password.isEmpty) {
      print("Password is empty!");
    } else if(confirmPass.isEmpty) {
      print("Re-enter password is empty!");
    } else if(password != confirmPass) {
      print("Password don't match!");
    } else {
      print("The value of Username is $username and the password is $password");
    }
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Center(
                child: SizedBox(
                  height: 600,
                  width: 300,
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleAvatar(
                            radius: 80.0,
                            backgroundImage: NetworkImage('https://hips.hearstapps.com/hmg-prod/images/elle-fanning-attends-the-2024-met-gala-celebrating-sleeping-news-photo-1715042420.jpg?resize=1200:*', scale: 80),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text('Create an account',
                              style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(bottom: 8.0),
                            child: TextField(
                              controller: idNumberController,
                              decoration: InputDecoration(
                                  label: Text('I.D Number'),
                                  border: OutlineInputBorder(),
                                  prefixIcon: Icon(Icons.card_membership)
                              ),
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(bottom: 8.0),
                            child: TextField(
                              controller: fullNameController,
                              decoration: InputDecoration(
                                  label: Text('Fullname'),
                                  border: OutlineInputBorder(),
                                  prefixIcon: Icon(Icons.text_fields)
                              ),
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(bottom: 8.0),
                            child: TextField(
                              controller: usernameController,
                              decoration: InputDecoration(
                                  label: Text('Username'),
                                  border: OutlineInputBorder(),
                                  prefixIcon: Icon(Icons.person_outline)
                              ),
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(bottom: 8.0),
                            child: TextField(
                              controller: passwordController,
                              obscureText: hidePassword,
                              decoration: InputDecoration(
                                  label: Text('Password'),
                                  border: OutlineInputBorder(),
                                  prefixIcon: Icon(Icons.password),
                                  suffixIcon: IconButton(
                                    onPressed: (){
                                      maskedUnmaskedPassword();
                                    },
                                    icon: Icon(Icons.remove_red_eye_outlined),
                                  )
                              ),
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(bottom: 8.0),
                            child: TextField(
                              controller: confirmPasswordController,
                              obscureText: hidePassword1,
                              decoration: InputDecoration(
                                  label: Text('Confirm Password'),
                                  border: OutlineInputBorder(),
                                  prefixIcon: Icon(Icons.password),
                                  suffixIcon: IconButton(
                                    onPressed: (){
                                      maskedUnmaskedPassword1();
                                    },
                                    icon: Icon(Icons.remove_red_eye_outlined),
                                  )
                              ),
                            ),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: SizedBox(
                              height: 40,
                              width: MediaQuery.of(context).size.width,
                              child: ElevatedButton(
                                  style: ButtonStyle(
                                      backgroundColor: WidgetStatePropertyAll(Colors.blue)
                                  ),
                                  onPressed: (){
                                    validateInput();
                                  }, child: Text('SIGN-UP', style: TextStyle(color: Colors.white),)
                              ),
                            ),
                          ),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text('Already have an account?'),
                              TextButton(onPressed: (){
                                Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context)=>LoginScreen()));
                              }, child: Text('LOGIN')
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}