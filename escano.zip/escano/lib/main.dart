import 'package:flutter/material.dart';
import 'LoginScreen.dart';


void main() {
  runApp(LoginScreen());
}

//https://hips.hearstapps.com/hmg-prod/images/elle-fanning-attends-the-2024-met-gala-celebrating-sleeping-news-photo-1715042420.jpg?resize=1200:*