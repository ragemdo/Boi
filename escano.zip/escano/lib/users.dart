import 'package:flutter/material.dart';

class Users extends StatefulWidget{
  const Users({super.key});

  @override
  State<Users> createState() => _UsersState();
}

class _UsersState extends State<Users> {
  var users = [
    {'id': 1, 'fullName': 'Ryan Angelo Escaño' , 'idNumber':20250001}, //0
    {'id': 2, 'fullName': 'Michelle Dohana Oliverio' , 'idNumber':20250002},//1
    {'id': 3, 'fullName': 'Ryan Angelo Escaño' , 'idNumber':20250003},//2
    {'id': 4, 'fullName': 'Michelle Dohana Oliverio' , 'idNumber':20250004},//2
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: users.length,
        itemBuilder: (context, i) {
          return ListTile(
            leading: Icon(Icons.account_box),
            title: Text(users[i]['fullName'].toString()),
            subtitle: Text(users[i]['idNumber'].toString()),
            trailing: Row(
              mainAxisSize: MainAxisSize.min ,
              children: [
                IconButton(onPressed: (){},
                    icon: Icon(Icons.edit)
                ),
                IconButton(onPressed: (){},
                    icon: Icon(Icons.delete)
                ),
              ],
            ),
          );
        }
    );
  }
}