import 'package:escano/profile.dart';
import 'package:escano/settings.dart';
import 'package:escano/users.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dashboard.dart';

class HomePage extends StatelessWidget{
  const HomePage({super.key});

@override
  Widget build(BuildContext context){
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    home: HomePageHome(),
  );
  }
}

class HomePageHome extends StatefulWidget{
  const HomePageHome({super.key});

  @override
  State<HomePageHome> createState() => _HomePageHomeState();
}

class _HomePageHomeState extends State<HomePageHome> {
  int selectedindex= 0;
  var routes = [Dashboard(),Settings(),Profile(),Users()];
  var hidePassword = true;

  void openModal(){
    switch (selectedindex){
      case 0:
        print('Selected Index is $selectedindex');
        break;
      case 1:
        print('Selected Index is $selectedindex');
        break;
      case 2:
        print('Selected Index is $selectedindex');
        break;
      case 3:
        print('Selected Index is $selectedindex');
        createNewUser(context);
        break;
      default:
        print('Select Index');
    }
  }

  void maskedUnmaskedPassword(){
    if(hidePassword == true) {
      setState(() {
        hidePassword = false;
      });
    } else {
      setState(() {
        hidePassword = true;
      });
    }
  }

  void createNewUser (BuildContext context){
    showModalBottomSheet(
    useSafeArea: true,
      context: context,
      builder: (BuildContext context){
      return Column(

        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Text('Add New User',),

          ),

          Padding(
            padding: const EdgeInsets.all(10.0),
            child: TextField(
              keyboardType: TextInputType.number, // Displays numeric keyboard
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly, // Restricts input to digits only
              ],
              decoration: InputDecoration(
                  label: Text('ID Number'),
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person_outline)
              ),
            ),
          ),

          Padding(

            padding: const EdgeInsets.all(10.0),
            child: TextField(
              decoration: InputDecoration(
                  label: Text('Full Name'),
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person_outline)
              ),
            ),
          ),


          Padding(
            padding: const EdgeInsets.all(10.0),
            child: TextField(
              decoration: InputDecoration(
                  label: Text('Username'),
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person_outline),
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              obscureText: hidePassword,
              decoration: InputDecoration(
                  label: Text('Password'),
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.password),
                  suffixIcon: IconButton(
                    onPressed: (){
                      maskedUnmaskedPassword();
                    },
                    icon: Icon(Icons.remove_red_eye_outlined),
                  )
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: SizedBox(
              height: 40,
              width: MediaQuery.of(context).size.width,
              child: ElevatedButton(
                  style: ButtonStyle(
                      backgroundColor: WidgetStatePropertyAll(Colors.blue)
                  ),
                  onPressed: (){
                  }, child: Text('Add User', style: TextStyle(color: Colors.white),)
              ),
            ),
          ),

        ],
      );
      }
    );
  }
  
@override
  Widget build(BuildContext context){
  return Scaffold(
    appBar: AppBar(
      title: Text('Flutter Activities'),
    ),
    drawer: Drawer(),
    body: routes[selectedindex],
    bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
      currentIndex: selectedindex,
        onTap:  (index){
        setState(() {
          selectedindex = index;
        });
        },

        items:[
          BottomNavigationBarItem(
              icon: Icon(Icons.dashboard,
                  color: Colors.black,),
            label:'Home'
          ),

          BottomNavigationBarItem(
              icon: Icon(Icons.settings,
              color: Colors.black,),
              label:'Settings',

          ),

          BottomNavigationBarItem(
            icon: Icon(Icons.person,
              color: Colors.black,),
            label:'Profile',

          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.list,
              color: Colors.black,),
            label:'Users',

          ),
        ]
    ),
    floatingActionButton: FloatingActionButton(
        onPressed:(){
          openModal();
        },
    child: Icon(Icons.add),
    ),
  );
  }
}